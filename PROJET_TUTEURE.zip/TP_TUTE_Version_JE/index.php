<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Se Connecter</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
    <div class="container">
        <div class="card">
            <h3>Connexion</h3>
            <form method="POST">
                <label for="username">Adresse Email</label><br>
                <input type="email" name="email" id="username" placeholder="Votre Email" required><br>
                <label for="password">Mot de Passe</label><br>
                <input type="password" name="password" id="password" placeholder="Votre mot de passe" required><br>
                <a href="#" class="forget">Mot de passe oublié ?</a><br>
                <input name="con" type="submit" value="Se Connecter">
            </form>
            <?php
                if (isset($_POST['con']) && isset($_POST['email']) && isset($_POST['password'])) {
                $user = $_POST['email'];
                $psw = $_POST['password'];

                include("model/bd.php");

                $req = $conn->query("SELECT * FROM users WHERE adresse = '$user' AND mdp = '$psw' ");
                $reponse = $req->fetch();
                $code = $reponse['code'];
                $_SESSION['lien'] = "espaces.php?code=".$code;

                include("controler/fonctions.php");
                Connexion($user, $psw);

                
            }
            ?>
            <p>Vous n'avez pas de compte?<a href="view/ins.php" class="signup">Cliquez ici</a></p>
        </div>
    </div>
</body>
</html>
