
<?php
	function Inscription($nom, $adresse, $mdp, $statut, $visibilite, $code){
		include("../model/bd.php");
    	$req = $conn->query("INSERT INTO users(nom, adresse, mdp, statut, visibilite, code)VALUES('$nom','$adresse','$mdp','$statut', '$visibilite', '$code')");
    }
















    function Connexion($user, $psw){

		include("model/bd.php");
    	$req = $conn->query("SELECT * FROM users WHERE adresse = '$user' AND mdp = '$psw' ");
        $reponse= $req->fetch();
        $count = $req->rowCount();

        if($count == 1){
                    $_SESSION['user'] = $user;
                    ?>
                        <script>
                            location.href = 'view/petit_foulet/index.php';
                        </script>
                    <?php
                } else {
                    ?>
                        <div style="color:red; font-weight: bold;">Nom d'utilisateur ou mot de passe incorrect</div>
                    <?php
                }
    }


















    function Creer_Espace($nom, $description, $categorie, $visibilite, $code){
		include("../model/bd.php");
    	$req = $conn->query("INSERT INTO espace(nom, description, categorie, visibilite, code)VALUES('$nom','$description', '$categorie', '$visibilite', '$code')");
    }















function Connexion_USER($user, $psw){

        include("../model/bd.php");
        $req = $conn->query("SELECT * FROM users WHERE adresse = '$user' AND mdp = '$psw' ");
        $reponse= $req->fetch();
        $count = $req->rowCount();

        if($count == 1){
                    $_SESSION['user'] = $user;
                    ?>
                        <script>
                            location.href = 'view/petit_foulet/index.php';
                        </script>
                    <?php
                } else {
                    ?>
                        <div style="color:red; font-weight: bold;">Nom d'utilisateur ou mot de passe incorrect</div>
                    <?php
                }
    }




























    function Pub_texte($code, $id_user, $texte, $doc){
        include("../model/bd.php");
        $req = $conn->query("INSERT INTO publication(code, id_user, texte, doc)VALUES('$code', '$id_user', '$texte', '$doc')");
    }


?>



