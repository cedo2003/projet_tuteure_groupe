<!-- Start User chat -->
            <div class="user-chat w-100 overflow-hidden">
                <div class="user-chat-overlay"></div>                

                <div class="chat-content d-lg-flex">
                    <!-- start chat conversation section -->
                    <div class="w-100 overflow-hidden position-relative">
                        <!-- conversation user -->
                        <div id="users-chat" class="position-relative">
                       
                        </div>
                        <!-- end chat input section -->
                    </div>
                    
                </div>
                <!-- end user chat content -->
            </div>
            <!-- End User chat -->