<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="animation.css">
  <title>Running Viking

  </title>
</head>
<body>
  <h1 style="text-align: center;">Notre Bonhomme vous laissera un message dans votre boite mail. Ce message est le lien pour creer votre espace !</h1>
  <div style="margin: auto;" class="frame">
    <div class="forest"></div>
    <div class="ground"></div>
    <div class="viking">
      <div class="viking__shoulderRight">
        <div class="viking__armRight">
          <div class="viking__handRight">
          </div>
        </div>
      </div>

      <div class="viking__legRight">
        <div class="viking__shinRight">
          <div class="viking__footRight">
            <div></div>
          </div>
        </div>
      </div>
      
      <div class="viking__legLeft">
        <div class="viking__shinLeft">
          <div class="viking__footLeft">
            <div></div>
          </div>
        </div>
      </div>

      <div class="viking__belt"></div>

      <div class="viking__head">
        <div class="viking__beard">
          <div></div>
        </div>

        <div class="viking__helmet">
          <div class="div"></div>
        </div>

        <div class="viking__face">
          <div class="viking__brows">

          </div>
        </div>
      </div>

      <div class="viking__shoulderLeft">
        <div class="viking__armLeft">
          <div class="viking__handLeft">
            <div class="viking__axe"></div>
          </div>
        </div>
      </div>

    </div>
  </div>

  <div style="font-size:30px;">
    Le lien est <a href="../<?= $_SESSION['lien'] ;?>"><?= $_SESSION['lien'] ;?></a>
  </div>
</body>
</html>