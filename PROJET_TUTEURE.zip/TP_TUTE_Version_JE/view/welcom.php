<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Workspace</title>
    <link rel="stylesheet" href="../welcom.css">
</head>

<body>
    <div class="header">
        <div class="header-text">
            <i>Welcome to Workspace</i>
        </div>
    </div>
    <div class="container">
        <div class="card">
            <h2>Bienvenue sur Workspace !</h2>
            <p>Nous sommes heureux de vous accueillir parmi nous. Worspace est une plateforme qui vous permet de
                <span>creer votre Espace Collaboratif de travail.</span></p>
            <p>WorkSpace vous facilite l'expérience utilisateur en vous offrant les fonctionnalités :</p>
            <ul>
                <li>Créez votre profil et connectez-vous avec d'autres utilisateurs.</li>
                <li>Partagez vos contenus et vos idées.</li>
                <li>Participez à des discussions et des événements.</li>
                <li>Accédez à des ressources et des outils exclusifs.</li>
            </ul>
            <p>N'hésitez pas à nous contacter si vous avez des questions.</p>
            <p><i>Le lien d'inscription pour les membres de votre Espace vous a été envoyé par E-mail. Veuillez donc le
                    consulter !</i></p>
        </div>
        <div class="link-container">
            <p class="link-text">Le lien Workspace est <a href="../<?= $_SESSION['con_user'] ;?>"><?= $_SESSION['con_user'] ;?></a></p>
        </div>
    </div>
</body>

</html>

</html>
