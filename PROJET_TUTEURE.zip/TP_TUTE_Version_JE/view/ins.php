
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=Lo, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <title>S'inscrire</title>
</head>
<body>
    <div class="container">
        <div class="card">
            <h3>Inscription</h3>
            <form method="POST">
                <label for="text">Nom et Prénom</label><br>
                <input type="text" name="name" id="name" placeholder="Votre Nom et Prénom" required><br>
                <label for="username">Adresse Email</label><br>
                <input type="email" name="email" id="username" placeholder="Votre Email" required><br>
                <label for="password">Mot de Passe</label><br>
                <input type="password" name="password1" id="password" placeholder="Votre mot de passe" required><br>
                <label for="password">Confirmez le Mot de Passe</label><br>
                <input type="password" name="password2" id="password" placeholder="Votre mot de passe" required><br>
                <a href="#" class="forget">Mot de passe oublié ?</a><br>
                <input name="ins" type="submit" value="S'inscrire">
                
                <p>Vous déjà un compte? Cliquez <a style="font-size: 20px; font-weight: bold;" href="../" class="signup">Connectez-vous</a></p>
                
            </form>

            <?php
                if($_POST){
                    if(isset($_POST['ins']) AND isset($_POST['name']) AND isset($_POST['email']) AND isset($_POST['password1']) AND isset($_POST['password2']) ){
                        if($_POST['password1'] == $_POST['password2']){
                            include("../model/bd.php");
                            $nom = $_POST['name'];
                            $adresse = $_POST['email'];
                            $mdp = $_POST['password2'];
                            $statut = "Admin";
                            $visibilite = "OUI";
                            $bytes = openssl_random_pseudo_bytes(4);
                            $pass = bin2hex($bytes);
                            $code = $pass;

                            include("../controler/fonctions.php");
                            Inscription($nom, $adresse, $mdp, $statut, $visibilite, $code);

                            
                            ?>
                                <script type="text/javascript">
                                    location.href = "../index.php";
                                </script>
                            <?php
                        }else{
                            echo "MOTS DE PASSES NON IDENTIQUES";
                        }
                    }
                }
                
                
            ?>
        </div>
    </div>


</body>
</html>
