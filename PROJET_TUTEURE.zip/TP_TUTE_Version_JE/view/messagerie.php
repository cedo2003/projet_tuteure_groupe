<?php
    session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <?php
        include("../model/bd.php");
        $req = $conn->query("SELECT * FROM espace WHERE code = '$_SESSION[espace]' ");
            $reponse= $req->fetch();
            $count = $req->rowCount();
            $nom_espace = $reponse['nom'];
    ?>
    <meta charset="utf-8" />
    <title><?= $nom_espace ;?> / WORKPACE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="../style.css">

</head>

<body>
    <div style="padding-bottom: 55px; " id="outer">
        <main style="position:fixed;" id="content-box" class="order-first">
            <div  class="header">
                <div class="logo">
                    <a href="index.php">ESPACE <?= $nom_espace ;?></a>
                </div>
                <div class="menu-toggle ">&#9776;</div> <!-- Bouton de basculement du menu -->
                    <nav class="navigation">
                        <ul>
                            <li><a href="index.php">ACCUEIL</a></li>
                            <li><a href="publier.php">PUBLIER</a></li>
                            <li><a href="#">REUNIONS</a></li>
                            <li><a href="messagerie.php" class="active">MESSAGERIE</a></li>
                            <li><a href="profil.php">MON PROFIL</a></li>
                        </ul>
                    </nav>
            </div>
        </main>
    </div>
    <?php 
        include('chat.php');
    ?>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/templatemo-script.js"></script>
    <script src="menu.js"></script>
</body>
</html>