<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=Lo, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <title>S'inscrire</title>
</head>
<body>
    <div class="container">
        <div class="card">
            <h3>ESPACE</h3>
            <form method="POST">
                <label for="text">Nom de l'Espace</label><br>
                <input type="text" name="name" id="name" placeholder="Nom de l'Espace" required><br>

                <label for="username">Description de l'Espace</label><br>
                <input type="text" name="description" id="description" placeholder="Description de l'espace" required><br>

                <label for="password">Catégorie de l'espace</label><br>
                <select style="width: 300px;align-content: center; padding: 10px;border: none; box-shadow: 0 2px 2px rgb(0,0,0,0.5); margin: auto;" type="text" name="categorie" id="password" required>
                    <option value="">-- Sélectionnez une thématique --</option>
                    <option value="education">Education</option>
                    <option value="sport">Sport</option>
                    <option value="loisirs">Loisirs</option>
                    <option value="musique">Musique</option>
                    <option value="cinema">Cinéma</option>
                    <option value="jeux-video">Jeux vidéo</option>
                    <option value="technologie">Technologie</option>
                    <option value="science">Science</option>
                    <option value="histoire">Histoire</option>
                    <option value="philosophie">Philosophie</option>
                    <option value="art">Art</option>
                    <option value="litterature">Littérature</option>
                    <option value="voyage">Voyage</option>
                    <option value="gastronomie">Gastronomie</option>
                    <option value="jardinage">Jardinage</option>
                    <option value="animaux">Animaux</option>
                    <option value="environnement">Environnement</option>
                    <option value="autres">Autres</option>
                </select><br>

                <label for="password">Visibilité de l'espace</label><br>
                <select style="width: 300px;align-content: center; padding: 10px;border: none; box-shadow: 0 2px 2px rgb(0,0,0,0.5); margin: auto;" type="text" name="visibilite" id="password" required>
                    <option value="">-- Sélectionnez une visibilite --</option>
                    <option>Public</option>
                    <option>Privée</option>
                </select><br><br>

                <input name="creer" type="submit" value="Creer l'Espace">
                
                
            </form>

            <?php
                if($_POST){
                    if(isset($_POST['creer']) AND isset($_POST['name']) AND isset($_POST['description']) AND isset($_POST['categorie']) AND isset($_POST['visibilite']) ){
                        
                            include("../model/bd.php");
                            $nom = $_POST['name'];
                            $description = $_POST['description'];
                            $categorie = $_POST['categorie'];
                            $visibilite = $_POST['visibilite'];
                            $code = $_GET['code'];

                            include("../controler/fonctions.php");
                            Creer_Espace($nom, $description, $categorie, $visibilite, $code);

                            
                            ?>
                                <script type="text/javascript">
                                    location.href = "welcom.php";
                                </script>
                            <?php

                            $_SESSION['con_user'] = "view/con_user.php?code=".$code;
                            
                        
                    }
                }
                
                
            ?>
        </div>
    </div>


</body>
</html>
