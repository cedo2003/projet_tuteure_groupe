<!doctype html>
<html lang="en">

    
<!-- Mirrored from themesbrand.com/doot/layouts/index by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 May 2022 08:43:29 GMT -->
<head>
        
        <meta charset="utf-8" />
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Doot - Responsive Chat App Template in HTML. A fully featured HTML chat messenger template in Bootstrap 5" name="description" />
        <meta name="keywords" content="Doot chat template, chat, web chat template, chat status, chat template, communication, discussion, group chat, message, messenger template, status"/>
        <meta content="Themesbrand" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico" id="tabIcon">

        <!-- glightbox css -->
        <link rel="stylesheet" href="assets/libs/glightbox/css/glightbox.min.css">

        <!-- swiper css -->
        <link rel="stylesheet" href="assets/libs/swiper/swiper-bundle.min.css">

        
        <!-- Bootstrap Css -->
        <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />


    </head>

    <body>

        <div class="layout-wrapper d-lg-flex">

            <!-- Start left sidebar-menu -->
            <div class="side-menu flex-lg-column">
                <!-- LOGO -->
                <div class="navbar-brand-box">
                    <a href="" class="logo logo-dark">
                        <span class="logo-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path d="M8.5,18l3.5,4l3.5-4H19c1.103,0,2-0.897,2-2V4c0-1.103-0.897-2-2-2H5C3.897,2,3,2.897,3,4v12c0,1.103,0.897,2,2,2H8.5z M7,7h10v2H7V7z M7,11h7v2H7V11z"/></svg>
                        </span>
                    </a>

                   
                </div>
                <!-- end navbar-brand-box -->

                <!-- Start side-menu nav -->
                <div class="flex-lg-column my-0 sidemenu-navigation">
                    <ul class="nav nav-pills side-menu-nav" role="tablist">
                        <li class="nav-item d-none d-lg-block" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-trigger="hover" data-bs-container=".sidemenu-navigation" title="Profil">
                            <a class="nav-link" id="pills-user-tab" data-bs-toggle="pill" href="#pills-user" role="tab">
                                <i class='bx bx-user-circle'></i>
                            </a>
                        </li>
                        <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-trigger="hover" data-bs-container=".sidemenu-navigation" title="Discussion">
                            <a class="nav-link active" id="pills-chat-tab" data-bs-toggle="pill" href="#pills-chat" role="tab">
                                <i class='bx bx-conversation'></i>
                            </a>
                        </li>

                        <li class="nav-item d-none d-lg-block" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-container=".sidemenu-navigation" data-bs-trigger="hover" title="Paramètre">
                            <a class="nav-link" id="pills-setting-tab" data-bs-toggle="pill" href="#pills-setting" role="tab">
                                <i class='bx bx-cog'></i>
                            </a>
                        </li>

                        <li class="nav-item dropdown profile-user-dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="assets/images/users/avatar-1.jpg" alt="" class="profile-user rounded-circle">
                            </a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item d-flex align-items-center justify-content-between" id="pills-user-tab" data-bs-toggle="pill" href="#pills-user" role="tab">Profile <i class="bx bx-user-circle text-muted ms-1"></i></a>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" id="pills-setting-tab" data-bs-toggle="pill" href="#pills-setting" role="tab">Setting <i class="bx bx-cog text-muted ms-1"></i></a>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" href="auth-changepassword.html">Change Password <i class="bx bx-lock-open text-muted ms-1"></i></a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item d-flex align-items-center justify-content-between" href="auth-logout.html">Log out <i class="bx bx-log-out-circle text-muted ms-1"></i></a>
                            </div>
                        </li>
                       
                        
                        <li  class="nav-item mt-auto">
                            <a class="nav-link light-dark" href="#" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-placement="right" data-bs-container=".sidemenu-navigation" data-bs-html="true" title="<span class='light-mode'>Mode sombre Désactivé</span> <span class='dark-mode'>Mode sombre AZctivé</span>">
                                <i class='bx bx-moon'></i>
                            </a>
                        </li>
                        
                        
                        
                        
                    </ul>
                </div>
                <!-- end side-menu nav -->
            </div>
            <!-- end left sidebar-menu -->

            <!-- start chat-leftsidebar -->
            <div class="chat-leftsidebar">

                <div class="tab-content">
                    <!-- Start Profile tab-pane -->
                    <div class="tab-pane" id="pills-user" role="tabpanel" aria-labelledby="pills-user-tab">
                        <!-- Start profile content -->
                        <div>
                            <div class="user-profile-img">
                                <img src="assets/images/small/img-4.jpg" class="profile-img" style="height: 160px;" alt="">
                                <div class="overlay-content">
                                    <div>
                                        <div class="user-chat-nav p-2 ps-3">
                    
                                            <div class="d-flex w-100 align-items-center">
                                                <div class="flex-grow-1">
                                                    <h5 class="text-white mb-0">Mon Profil</h5>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <div class="dropdown">
                                                        <button class="btn nav-btn text-white dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <i class='bx bx-dots-vertical-rounded'></i>
                                                        </button>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a class="dropdown-item d-flex align-items-center justify-content-between" href="#">Info <i class="bx bx-info-circle ms-2 text-muted"></i></a>
                                                            <a class="dropdown-item d-flex align-items-center justify-content-between" href="#">Setting <i class="bx bx-cog text-muted ms-2"></i></a>
                                                            <div class="dropdown-divider"></div>
                                                            <a class="dropdown-item d-flex align-items-center justify-content-between" href="#">Help <i class="bx bx-help-circle ms-2 text-muted"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center p-3 p-lg-4 border-bottom pt-2 pt-lg-2 mt-n5 position-relative">
                                <div class="mb-lg-3 mb-2">
                                    <img src="assets/images/users/avatar-1.jpg" class="rounded-circle avatar-lg img-thumbnail" alt="">
                                </div>

                                <h5 class="font-size-16 mb-1 text-truncate">Adam Zampa</h5>
                                <p class="text-muted font-size-14 text-truncate mb-0">Front end Developer</p>
                            </div>
                            <!-- End profile user -->

                            <!-- Start user-profile-desc -->
                            <div class="p-4 profile-desc" data-simplebar>
                                <div class="text-muted">
                                    <p class="mb-4">If several languages coalesce, the grammar of the resulting language is more simple.</p>
                                </div>

                                <div>
                                    <div class="d-flex py-2">
                                        <div class="flex-shrink-0 me-3">
                                            <i class="bx bx-user align-middle text-muted"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0">Adam Zampa</p>
                                        </div>
                                    </div>

                                    <div class="d-flex py-2">
                                        <div class="flex-shrink-0 me-3">
                                            <i class="bx bx-message-rounded-dots align-middle text-muted"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0">adc@123.com</p>
                                        </div>
                                    </div>
            
                                    
                                </div>
                                

                                
                            </div>
                            <!-- end user-profile-desc -->
                        </div>
                        <!-- End profile content -->
                    </div> 
                    <!-- End Profile tab-pane -->

                    <!-- Start chats tab-pane -->
                    <div class="tab-pane show active" id="pills-chat" role="tabpanel" aria-labelledby="pills-chat-tab">
                        <!-- Start chats content -->
                        <div>
                            <div class="px-4 pt-4">
                                <div class="d-flex align-items-start">
                                    <div class="flex-grow-1">
                                        <h4 class="mb-4">Discussions</h4>
                                    </div>
                                    
                                </div>
                                <form>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control bg-light border-0 pe-0" id="serachChatUser" onkeyup="searchUser()" placeholder="Search here.." 
                                        aria-label="Example text with button addon" aria-describedby="searchbtn-addon" autocomplete="off">
                                        <button class="btn btn-light" type="button" id="searchbtn-addon"><i class='bx bx-search align-middle'></i></button>
                                    </div>
                                </form>

                            </div> <!-- .p-4 -->

                            <div class="chat-room-list" data-simplebar>
                                <!-- Start chat-message-list -->
                                <h5 class="mb-3 px-4 mt-4 font-size-11 text-muted text-uppercase">Favories</h5>

                                <div class="chat-message-list">
            
                                    <ul class="list-unstyled chat-list chat-user-list" id="favourite-users">
                                    </ul>
                                </div>

                                <div class="d-flex align-items-center px-4 mt-5 mb-2">
                                    <div class="flex-grow-1">
                                        <h4 class="mb-0 font-size-11 text-muted text-uppercase">Messages directs</h4>
                                    </div>
                                    <div class="flex-shrink-0">
                                        <div data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-placement="bottom" title="New Message">

                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-soft-primary btn-sm" data-bs-toggle="modal" data-bs-target=".contactModal">
                                                <i class="bx bx-plus"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="chat-message-list">
            
                                    <ul class="list-unstyled chat-list chat-user-list" id="usersList">
                
                                    </ul>
                                </div>

                               

                                <div class="chat-message-list">
            
                                    <ul class="list-unstyled chat-list chat-user-list mb-3" id="channelList">
                
                                    </ul>
                                </div>
                                <!-- End chat-message-list -->
                            </div>

                        </div>
                       
                    </div>
                    
                   
                    
                    
                    <!-- Start settings tab-pane -->
                    <div class="tab-pane" id="pills-setting" role="tabpanel" aria-labelledby="pills-setting-tab">
                        <!-- Start Settings content -->
                        <div>
                            <div class="user-profile-img">
                                <img src="assets/images/small/img-4.jpg" class="profile-img profile-foreground-img" style="height: 160px;" alt="">
                                <div class="overlay-content">
                                    <div>
                                        <div class="user-chat-nav p-3">
                    
                                            <div class="d-flex w-100 align-items-center">
                                                <div class="flex-grow-1">
                                                    <h5 class="text-white mb-0">Paramètres</h5>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <div class="avatar-xs p-0 rounded-circle profile-photo-edit" data-bs-toggle="tooltip" data-bs-trigger="hover" data-bs-placement="bottom" title="Change Background">
                                                        <input id="profile-foreground-img-file-input" type="file" class="profile-foreground-img-file-input" >
                                                        <label for="profile-foreground-img-file-input" class="profile-photo-edit avatar-xs">
                                                            <span class="avatar-title rounded-circle bg-light text-body">
                                                                <i class="bx bxs-pencil"></i>
                                                            </span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center p-3 p-lg-4 border-bottom pt-2 pt-lg-2 mt-n5 position-relative">
                                <div class="mb-3 profile-user">
                                    <img src="assets/images/users/avatar-1.jpg" class="rounded-circle avatar-lg img-thumbnail user-profile-image" alt="user-profile-image">
                                    <div class="avatar-xs p-0 rounded-circle profile-photo-edit">
                                        <input id="profile-img-file-input" type="file" class="profile-img-file-input" >
                                        <label for="profile-img-file-input" class="profile-photo-edit avatar-xs">
                                            <span class="avatar-title rounded-circle bg-light text-body">
                                                <i class="bx bxs-camera"></i>
                                            </span>
                                        </label>
                                    </div>
                                </div>

                                <h5 class="font-size-16 mb-1 text-truncate"></h5>
        
                                <div class="dropdown d-inline-block">
                                    <a class="text-muted dropdown-toggle d-block" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="bx bxs-circle text-success font-size-10 align-middle"></i> Active <i class="mdi mdi-chevron-down"></i>
                                    </a>
          
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="#"><i class="bx bxs-circle text-success font-size-10 me-1 align-middle"></i> Active</a>
                                        <a class="dropdown-item" href="#"><i class="bx bxs-circle text-warning font-size-10 me-1 align-middle"></i> Away</a>
                                        <a class="dropdown-item" href="#"><i class="bx bxs-circle text-danger font-size-10 me-1 align-middle"></i> Do not disturb</a>
                                    </div>
                                </div>

        
                            </div>
                            <!-- End profile user -->

                            <!-- Start User profile description -->
                            <div class="user-setting" data-simplebar>
                                <div id="settingprofile" class="accordion accordion-flush">
                                    <div class="accordion-item">
                                        <div class="accordion-header" id="headerpersonalinfo">
                                            <button class="accordion-button font-size-14 fw-medium" type="button" data-bs-toggle="collapse" data-bs-target="#personalinfo" aria-expanded="true" aria-controls="personalinfo">
                                                <i class="bx bxs-user text-muted me-3"></i> Informations Personnelles
                                            </button>
                                        </div>
                                        <div id="personalinfo" class="accordion-collapse collapse show" aria-labelledby="headerpersonalinfo" data-bs-parent="#settingprofile">
                                            <div class="accordion-body">
                                                <div class="float-end">
                                                    <button type="button" class="btn btn-soft-primary btn-sm"><i class="bx bxs-pencil align-middle"></i></button>
                                                </div>

                                                <div>
                                                    <p class="text-muted mb-1">Nom et Prénom</p>
                                                    <h5 class="font-size-14">Adam Zampa</h5>
                                                </div>

                                                <div class="mt-4">
                                                    <p class="text-muted mb-1">Email</p>
                                                    <h5 class="font-size-14">adc@123.com</h5>
                                                </div>

                                                <div class="mt-4">
                                                    <p class="text-muted mb-1">Adresse</p>
                                                    <h5 class="font-size-14 mb-0">California, USA</h5>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end personal info card -->

                                    <div class="accordion-item">
                                        <div class="accordion-header" id="headerthemes">
                                            <button class="accordion-button font-size-14 fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsethemes" aria-expanded="false" aria-controls="collapsethemes">
                                                <i class="bx bxs-adjust-alt text-muted me-3"></i> Themes
                                            </button>
                                        </div>
                                        <div id="collapsethemes" class="accordion-collapse collapse" aria-labelledby="headerthemes" data-bs-parent="#settingprofile">
                                            <div class="accordion-body">
                                                <div>
                                                    <h5 class="mb-3 font-size-11 text-muted text-uppercase">Choose Theme Color :</h5>
                                                    <div class="d-flex align-items-center flex-wrap gap-2 theme-btn-list theme-color-list">
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-color" type="radio" value="0" name="bgcolor-radio" id="bgcolor-radio1" >
                                                            <label class="form-check-label avatar-xs" for="bgcolor-radio1">
                                                                <span class="avatar-title bg-primary-custom rounded-circle theme-btn bgcolor-radio1"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-color" type="radio" value="1" name="bgcolor-radio" id="bgcolor-radio2">
                                                            <label class="form-check-label avatar-xs" for="bgcolor-radio2">
                                                                <span class="avatar-title bg-info rounded-circle theme-btn bgcolor-radio2"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-color" type="radio" value="2" name="bgcolor-radio" id="bgcolor-radio4">
                                                            <label class="form-check-label avatar-xs" for="bgcolor-radio4">
                                                                <span class="avatar-title bg-purple rounded-circle theme-btn bgcolor-radio4"></span>
                                                            </label>
                                                        </div>
                                
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-color" type="radio" value="3" name="bgcolor-radio" id="bgcolor-radio5">
                                                            <label class="form-check-label avatar-xs" for="bgcolor-radio5">
                                                                <span class="avatar-title bg-pink rounded-circle theme-btn bgcolor-radio5"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-color" type="radio" value="4" name="bgcolor-radio" id="bgcolor-radio6">
                                                            <label class="form-check-label avatar-xs" for="bgcolor-radio6">
                                                                <span class="avatar-title bg-danger rounded-circle theme-btn bgcolor-radio6"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-color" type="radio" value="5" name="bgcolor-radio" id="bgcolor-radio7">
                                                            <label class="form-check-label avatar-xs" for="bgcolor-radio7">
                                                                <span class="avatar-title bg-secondary rounded-circle theme-btn bgcolor-radio7"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-color" type="radio" value="6" name="bgcolor-radio" id="bgcolor-radio8" checked>
                                                            <label class="form-check-label avatar-xs light-background" for="bgcolor-radio8">
                                                                <span class="avatar-title bg-light rounded-circle theme-btn bgcolor-radio8"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="mt-4 pt-2">
                                                    <h5 class="mb-3 font-size-11 text-muted text-uppercase">Choose Theme Image :</h5>
                                                    <div class="d-flex align-items-center flex-wrap gap-2 theme-btn-list theme-btn-list-img">
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio1">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio1">
                                                                <span class="avatar-title bg-pattern-1 rounded-circle theme-btn bgimg-radio1"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio2">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio2">
                                                                <span class="avatar-title bg-pattern-2 rounded-circle theme-btn bgimg-radio2"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio3">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio3">
                                                                <span class="avatar-title bg-pattern-3 rounded-circle theme-btn bgimg-radio3"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio4">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio4">
                                                                <span class="avatar-title bg-pattern-4 rounded-circle theme-btn bgimg-radio4"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio5" checked>
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio5">
                                                                <span class="avatar-title bg-pattern-5 rounded-circle theme-btn bgimg-radio5"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio6">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio6">
                                                                <span class="avatar-title bg-pattern-6 rounded-circle theme-btn bgimg-radio6"></span>
                                                            </label>
                                                        </div>
                                
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio7">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio7">
                                                                <span class="avatar-title bg-pattern-7 rounded-circle theme-btn bgimg-radio7"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio8">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio8">
                                                                <span class="avatar-title bg-pattern-8 rounded-circle theme-btn bgimg-radio8"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input theme-img" type="radio" name="bgimg-radio" id="bgimg-radio9">
                                                            <label class="form-check-label avatar-xs" for="bgimg-radio9">
                                                                <span class="avatar-title bg-pattern-9 rounded-circle theme-btn bgimg-radio9"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <!-- end privacy card -->

                                    <div class="accordion-item">
                                        <div class="accordion-header" id="headersecurity">
                                            <button class="accordion-button font-size-14 fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsesecurity" aria-expanded="false" aria-controls="collapsesecurity">
                                                <i class="bx bxs-check-shield text-muted me-3"></i> Securité
                                            </button>
                                        </div>
                                        <div id="collapsesecurity" class="accordion-collapse collapse" aria-labelledby="headersecurity" data-bs-parent="#settingprofile">
                                            <div class="accordion-body">
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item p-0">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex-grow-1 overflow-hidden">
                                                                <h5 class="font-size-13 mb-0 text-truncate">Show security notification</h5>
        
                                                            </div>
                                                            <div class="flex-shrink-0 ms-2">
                                                                <div class="form-check form-switch">
                                                                    <input type="checkbox" class="form-check-input" id="security-notificationswitch">
                                                                    <label class="form-check-label" for="security-notificationswitch"></label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end security card -->

            

                                    <div class="accordion-item">
                                        <div class="accordion-header" id="headerhelp">
                                            <button class="accordion-button font-size-14 fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsehelp" aria-expanded="false" aria-controls="collapsehelp">
                                                <i class="bx bxs-help-circle text-muted me-3"></i> Aide
                                            </button>
                                        </div>
                                        <div id="collapsehelp" class="accordion-collapse collapse" aria-labelledby="headerhelp" data-bs-parent="#settingprofile">
                                            <div class="accordion-body">
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item py-3 px-0 pt-0">
                                                        <h5 class="font-size-13 mb-0"><a href="#" class="text-body d-block">FAQs</a></h5>
                                                    </li>
                                                    <li class="list-group-item py-3 px-0">
                                                        <h5 class="font-size-13 mb-0"><a href="#" class="text-body d-block">Contact</a></h5>
                                                    </li>
                                                    <li class="list-group-item py-3 px-0 pb-0">
                                                        <h5 class="font-size-13 mb-0"><a href="#" class="text-body d-block">Terms & Privacy policy</a></h5>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- end profile-setting-accordion -->
                            </div>
                            <!-- End User profile description -->
                        </div>
                        <!-- Start Settings content -->
                    </div>
                    <!-- End settings tab-pane -->
                </div>
                <!-- end tab content -->
            </div>
            <!-- end chat-leftsidebar -->

            <?php 
                if(isset($_GET["id_receive"])){
                    include("face_chat.php");
                }else{
                    include("face_chat_vide.php");
                }
            ?>

           

            
            <!-- contactModal -->
            <div class="modal fade contactModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content modal-header-colored shadow-lg border-0">
                        <div style="background:linear-gradient(20deg, #081841, #0068bd);" class="modal-header">
                            <h5 class="modal-title text-white font-size-16">Contacts</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                        <div class="modal-body p-4">
                            
                            <div class="input-group mb-4">
                                <input type="text" class="form-control bg-light border-0 pe-0" placeholder="Rechercher.." id="searchContactModal" onkeyup="searchContactOnModal()" 
                                aria-label="Example text with button addon" aria-describedby="contactSearchbtn-addon">
                                <button class="btn btn-light" type="button" id="contactSearchbtn-addon"><i class='bx bx-search align-middle'></i></button>
                            </div>

                            <div class="d-flex align-items-center px-1">
                                <div class="flex-grow-1">
                                    <h4 class=" font-size-11 text-muted text-uppercase">Contacts</h4>
                                </div>
                            </div>
<br>
                            <div style="padding-left:50px; height: 250px; overflow:scroll;">
                            <?php 
                                $liste = $conn->query("SELECT * FROM users WHERE code = '$_SESSION[espace]' ");
                                while($li = $liste->fetch()){
                                    ?>
                                        <div class="contact-modal-list mx-n4 px-1" data-simplebar >

                                            <div><a style="font-weight:bold;" href="messagerie.php?id_receive=<?= $li['id_user'] ;?>"><h5 class="font-size-14 m-0"><?= $li['nom'] ;?></h5></a><hr></div>
   
                                        </div><br>
                                    <?php
                                }
                            ?>
                            </div>
                            

                        </div>       
                                       
                    </div>
                </div>
                
            </div>
        
        </div>
        <!-- end  layout wrapper -->

        <!-- JAVASCRIPT -->
        <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/libs/simplebar/simplebar.min.js"></script>
        <script src="assets/libs/node-waves/waves.min.js"></script>
        
        <!-- glightbox js -->
        <script src="assets/libs/glightbox/js/glightbox.min.js"></script>

        <!-- Swiper JS -->
        <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

        <!-- fg-emoji-picker JS -->
        <script src="assets/libs/fg-emoji-picker/fgEmojiPicker.js"></script>

        <!-- page init -->
        <script src="assets/js/pages/index.init.js"></script>

        <script src="assets/js/app.js"></script>
    </body>

<!-- Mirrored from themesbrand.com/doot/layouts/index by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 06 May 2022 08:43:55 GMT -->
</html>
