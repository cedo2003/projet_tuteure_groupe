<?php
    session_start();
    include("../model/bd.php");

    if (isset($_POST['con_user'], $_POST['email'], $_POST['password'])) {
        $user = $_POST['email'];
        $psw = $_POST['password'];

        $req = $conn->prepare("SELECT * FROM users WHERE adresse = ? AND mdp = ?");
        $req->execute([$user, $psw]);
        $count = $req->rowCount();

        if ($count == 1) {
            $reponse = $req->fetch();
            $_SESSION['adresse'] = $reponse['adresse'];
            $_SESSION['espace'] = $reponse['code'];
            header("Location: index.php");
            exit();
        } else {
            $error_message = "Nom d'utilisateur ou mot de passe incorrect";
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Se Connecter</title>
  <link rel="stylesheet" href="../style.css">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
<?php
    include("../model/bd.php");
    $req = $conn->query("SELECT * FROM espace WHERE code = '$_GET[code]' ");
    $es = $req->fetch();
    $nom_espace = $es['nom'];
  ?>
<div class="container">
    <div class="card">
    <div class="espace-title">ESPACE <?= $nom_espace ;?></div>
        <h3>Connexion</h3>
        <form method="POST">
            <label for="username">Adresse Email</label><br>
            <input type="email" name="email" id="username" placeholder="Votre Email" required><br>

            <label for="password">Mot de Passe</label><br>
            <input type="password" name="password" id="password" placeholder="Votre mot de passe" required><br>

            <a href="#" class="forget">Mot de passe oublié ?</a><br>
            <input type="submit" name="con_user" value="Se Connecter" class="submit-button">

            <p><?php if (isset($error_message)) { echo $error_message; } ?></p>
            <p>Vous n'avez pas de compte ? <a href="workspace.php?code=<?= $_GET['code'] ;?>" class="signup">Inscrivez-vous</a></p>
        </form>
    </div>
</div>

</body>
</html>
