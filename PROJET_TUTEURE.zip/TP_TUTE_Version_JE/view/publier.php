<?php
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <?php

        
        include("../model/bd.php");
        $req = $conn->query("SELECT * FROM espace WHERE code = '$_SESSION[espace]' ");
            $reponse= $req->fetch();
            $count = $req->rowCount();
            $nom_espace = $reponse['nom'];
    ?>
    <meta charset="utf-8" />
    <title><?= $nom_espace ;?> / WORKPACE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
    <link rel="stylesheet" href="fontawesome/css/all.min.css" type="text/css" /> 
    <link rel="stylesheet" href="css/slick.css" type="text/css" />   
    <link rel="stylesheet" href="css/tooplate-simply-amazed.css" type="text/css" />
    <link rel="stylesheet" href="../style.css">
<style>
        #popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8); 
        }
        #pop {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8); 
        }

        #popup-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border-radius: 5px;
        }
        #content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 30px;
            border-radius: 5px;
        }

        #close-button {
            float: right;
            cursor: pointer;
        }
        #close{
            float: right;
            cursor: pointer;
        }

        td{
            padding: 20px;
        }
        
       

</style>
</head>
<body>     
    <div id="outer">
        <main id="content-box" class="order-first">
            <div class="header">
                <div class="logo">
                    <a href="index.php">ESPACE <?= $nom_espace ;?></a>
                </div>
                <div class="menu-toggle ">&#9776;</div> <!-- Bouton de basculement du menu -->
                    <nav class="navigation">
                        <ul>
                            <li><a href="index.php">ACCUEIL</a></li>
                            <li><a href="publier.php"  class="active">PUBLIER</a></li>
                            <li><a href="#">REUNIONS</a></li>
                            <li><a href="messagerie.php">MESSAGERIE</a></li>
                            <li><a href="profil.php">MON PROFIL</a></li>
                        </ul>
                    </nav>
            </div>
        </main>
    </div>
    <!--Publication -->
    <h1 class="publication-title">Faire une publication</h1>
    <div class="demande-container">
        <div class="demande">
        <div class="ball"></div>
  <div class="ball"></div>
  <div class="ball"></div>
            <div><a href="#" id="open-popup" class="publish-text-btn">PUBLIER UN TEXTE</a></div><br><br>
            <div><a href="#" id="open-pop" class="edit-document-btn">EDITER UN NOUVEAU DOCUMENT</a></div>                   
        </div>
    </div>


    <div id="popup">
        <div class="popup-content">
            <h2 class="popup-title">PUBLIER UN TEXTE</h2>
            <form class="publish-form" method="POST">
                <div class="form-group">
                    <label for="texte" class="form-label">Texte à publier</label>
                    <textarea id="texte" name="texte" class="form-control" required></textarea>
                </div>
                <input type="submit" class="btn-publish" name="val" value="Valider">
            </form>
            <button class="btn-close" id="close-button">Fermer</button>
        </div>
    </div>

                    <?php
                        if($_POST){
                            if(isset($_POST['val']) AND isset($_POST['texte']) ){
                        
                                    include("../model/bd.php");
                                    $texte = $_POST['texte'];
                                    $adresse = $_SESSION['adresse'];
                                    $code = $_SESSION['espace'];
                                    $doc = "";
                                    $titredoc = "";

                                    $rec = $conn->query("SELECT * FROM users WHERE code = '$code' AND adresse = '$adresse' ");
                                    $rech = $rec->fetch();
                                    $id_user = $rech['id_user'];
                                    $code = $rech['code'];
                            
                                    $sql = "INSERT INTO publication (code, id_user, texte, doc, titredoc) VALUES (:code, :id_user, :texte, :doc, :titredoc)";
                                    $stmt = $conn->prepare($sql);

                                    $stmt->bindParam(':code', $code);
                                    $stmt->bindParam(':id_user', $id_user);
                                    $stmt->bindParam(':texte', $texte);
                                    $stmt->bindParam(':doc', $doc);
                                    $stmt->bindParam(':titredoc', $titredoc);
        
                                    if ($stmt->execute()) {

                                        ?>
                                        <script type="text/javascript">
                                            location.href = "publier.php";
                                        </script>
                                        <?php
                                    }

                                    

                                

                            
                                    
                        
                            }
                        }
                
                
                    ?>
                </div>




<div class="popup" id="pop">
    <div class="popup-content">
        <h2 class="popup-title">ÉDITER UN NOUVEAU DOCUMENT</h2>

        <form class="publish-form" method="POST">
        

            <div class="form-group">
                <label class="form-label" for="titre">Nom du Document</label>
                <input class="form-control" type="text" id="titre" name="titre" required>
            </div>

            <div class="form-group">
                <label for="texte" class="form-label">Contenu du Document</label>
                <textarea class="form-control" id="texte" name="content"  required></textarea>
            </div>

            <input class="btn-publish" type="submit" name="env" value="Enregistrer">
        </form>

        <button class="btn-close" id="close">Fermer</button>
    </div>
</div>


                    <?php
            
                        include("../model/bd.php");

                            if($_POST){
                                if(isset($_POST['content']) AND isset($_POST['env'])){
        
                                    $content = $_POST['content'];
                                    $ti = $_POST['titre'];
                                    $adresse = $_SESSION['adresse'];
                                    $code = $_SESSION['espace'];
                                    $texte = "";
                                    $titre = str_replace(' ','', $ti);

                                    $rec = $conn->query("SELECT * FROM users WHERE code = '$code' AND adresse = '$adresse' ");
                                    $rech = $rec->fetch();
                                    $id_user = $rech['id_user'];
                                    $code = $rech['code'];

                                    $sql = "INSERT INTO publication (code, id_user, texte, doc, titredoc) VALUES (:code, :id_user, :texte, :doc, :titredoc)";
                                    $stmt = $conn->prepare($sql);

                                    $stmt->bindParam(':code', $code);
                                    $stmt->bindParam(':id_user', $id_user);
                                    $stmt->bindParam(':texte', $texte);
                                    $stmt->bindParam(':doc', $content);
                                    $stmt->bindParam(':titredoc', $titre);
        
                                    if ($stmt->execute()) {
                                       
                                        ?>
                                            <script type="text/javascript">
                                                location.href = "publier.php";
                                            </script>
                                        <?php
                                    }else {
                                        echo "Erreur lors de l'enregistrement du document ";
                                    }   
                                }
                            }

                    ?>
                </div>

                


    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/templatemo-script.js"></script>
    <script>
        const openButton = document.getElementById("open-popup");
        const popup = document.getElementById("popup");
        const closeButton = document.getElementById("close-button");

        closeButton.addEventListener("click", () => {
            popup.style.display = "none";
        });

        openButton.addEventListener("click", () => {
            popup.style.display = "block";
        });

        const open = document.getElementById("open-pop");
        const pop = document.getElementById("pop");
        const close = document.getElementById("close");

        close.addEventListener("click", () => {
            pop.style.display = "none";
        });

        open.addEventListener("click", () => {
            pop.style.display = "block";
        });
    </script>
    <script src="menu.js"></script>
</body>
</html>

<style type="text/css">
    /* Style général du formulaire */
.formulaire {
  width: 100%;
  max-width: 400px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

/* Style des champs */
.champ {
  margin-bottom: 10px;
}

.champ label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

.champ input, textarea {
  width: 100%;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

/* Style du bouton */
.formulaire button {
  margin-top: 10px;
  padding: 5px 10px;
  font-size: 16px;
  font-weight: bold;
  color: #fff;
  background-color: #000;
  border: 1px solid #000;
  border-radius: 5px;
  cursor: pointer;
}

/* Animation du bouton */
.formulaire button:hover {
  background-color: #333;
}

/* Responsive */
@media (max-width: 768px) {
  .formulaire {
    max-width: 100%;
  }
}

</style>