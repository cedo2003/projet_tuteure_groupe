<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        include("../model/bd.php");
        $req = $conn->query("SELECT * FROM espace WHERE code = '$_SESSION[espace]'");
        $reponse = $req->fetch();
        $nom_espace = $reponse['nom'];
    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $nom_espace ;?> / WORKSPACE</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div style="padding-bottom:60px;" id="outer">
        <main id="content-box" class="order-first">
            <div  class="header">
                <div class="logo">
                    <a href="index.php">ESPACE <?= $nom_espace ;?></a>
                </div>
                <div class="menu-toggle ">&#9776;</div> <!-- Bouton de basculement du menu -->
                    <nav class="navigation">
                        <ul>
                            <li><a href="index.php" class="active">ACCUEIL</a></li>
                            <li><a href="publier.php">PUBLIER</a></li>
                            <li><a href="#">REUNIONS</a></li>
                            <li><a href="messagerie.php">MESSAGERIE</a></li>
                            <li><a href="profil.php">MON PROFIL</a></li>
                        </ul>
                    </nav>
            </div>
        </main>
    </div>

          
    <div style="margin-bottom:-10px;" class="search-bar">
        <form method="POST">
           <div style="display:flex;">
                <div><input type="search" name="recherche" placeholder="Rechercher"></div>
                <div><button type="submit" name="env">Rechercher</button></div>
           </div>
        </form>
    </div>

    <div class="container_pub">
    <div class="publication-section">
    <?php
        $vide = "";
        $recherche = $conn->query("SELECT * FROM publication WHERE code = '$_SESSION[espace]' ORDER BY id_pub DESC");
        while ($aff = $recherche->fetch()) {
            $user = $conn->query("SELECT * FROM users WHERE id_user = '$aff[id_user]' ");
            $info = $user->fetch();
            $name = $info['nom'];

            if ($aff['texte'] != "") {
    ?>
                <div class="publication-item">
                    <div class="user-info">
                        <img src="../img/per.jpeg" alt="user Image" class="user-avatar">
                        <div class="username"><?= $name ?></div>
                    </div>
                    <div class="text-content"><?= $aff['texte'] ?></div>
                    <div class="interaction">
                        <div class="like">J'aime <span  style="font-weight:bold;">0</span></div>
                        <div class="comment"><span  style="font-weight:bold;">0</span> Commentaires</div>
                    </div>
                    <div class="action-buttons">
                        <div class="like-button">J'aime</div>
                        <a href="comment.php?id_pub=<?= $aff['id_pub'] ?>&amp;id_user=<?= $aff['id_user'] ?>" class="comment-button">Commenter</a>
                    </div>
                </div>
    <?php
            } else {
    ?>
                <div class="publication-item">
                    <div class="user-info">
                        <img src="../img/per.jpeg" alt="User Image" class="user-avatar">
                        <div class="username"><?= $name ?></div>
                    </div>
                    <div class="document-link">
                        <a style="background-color:skyblue; color:white; font-weight: bold; padding:3px;" href="doc.php?iddoc=<?= $aff['id_pub'] ?>" class="document"><?= $aff['titredoc'] ?>.txt</a>
                    </div>
                    <div class="interaction">
                        <div class="like">J'aime <span style="font-weight:bold;">0</span></div>
                        <div class="comment"><span style="font-weight:bold;">0</span> Commentaires</div>
                    </div>
                    <div class="action-buttons">
                        <div class="like-button">J'aime</div>
                        <a href="comment.php?id_pub=<?= $aff['id_pub'] ?>&amp;id_user=<?= $aff['id_user'] ?>" class="comment-button">Commenter</a>
                    </div>
                </div>
    <?php
            }
        }
    ?>
</div>
</div>

        </main>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/templatemo-script.js"></script>
    <script src="menu.js"></script>
</body>
</html>
