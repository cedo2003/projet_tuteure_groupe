-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 06 avr. 2024 à 07:41
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tp_tute`
--

-- --------------------------------------------------------

--
-- Structure de la table `archives`
--

CREATE TABLE `archives` (
  `id` int(11) NOT NULL,
  `adresse_archiveur` varchar(11) NOT NULL,
  `id_archivee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE `commentaires` (
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `texte` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `espace`
--

CREATE TABLE `espace` (
  `id_espace` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `categorie` varchar(50) NOT NULL,
  `visibilite` varchar(50) NOT NULL,
  `code` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `espace`
--

INSERT INTO `espace` (`id_espace`, `nom`, `description`, `categorie`, `visibilite`, `code`) VALUES
(1, 'Juali', 'jqjss shdhdhd', 'science', 'Public', '32d23109');

-- --------------------------------------------------------

--
-- Structure de la table `publication`
--

CREATE TABLE `publication` (
  `id_pub` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `texte` varchar(255) NOT NULL,
  `doc` text DEFAULT NULL,
  `titredoc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `publication`
--

INSERT INTO `publication` (`id_pub`, `code`, `id_user`, `texte`, `doc`, `titredoc`) VALUES
(5, '32d23109', 2, '', 'CÉDRIC LÉGER\r\nJUNIOR\r\nHOUNMADJAÏ\r\nD E V E L O P P E U R\r\nW E B / M O B I L E\r\n229 99017524\r\nAbomey-calavi , maison\r\nHOUNMADJAI\r\njuniorhounmadjai@gmail.com\r\nDéveloppeur web / Mobile passionné et créatif, je\r\npossède une solide expertise dans la conception et la\r\nmise en œuvre de solutions web/Mobile innovantes.\r\nFort d\'une formation approfondie et d\'une\r\nexpérience pratique, je maîtrise les langages de\r\nprogrammation front-end et back-end, ainsi que les\r\ntechnologies modernes du développement\r\nweb/Mobile\r\nPHP\r\nHTML, CSS, JAVASCRIPT\r\nC, C++\r\nBases de données, SQL, PLSQL\r\navec Oracle SQL developer\r\nFlutter\r\nAdministration Linux\r\nMaitrise d’hebergement web ,\r\nutilisation de FileZila Client etc …\r\nFrançais\r\nAnglais\r\nFon\r\nC O M P E T E N C E S\r\nL A N G U E S P A R L É E S\r\nF O R M A T I O N\r\nE X P E R I E N C E S\r\nStartup de développement de solutions informatiques\r\nDéveloppement de la plateforme de simulation de la\r\nDGPD(Direction général des politiques de développement)\r\n2020-2021\r\n2023\r\nSTAGE A RAB-TECH\r\nDEVELOPPEUR A SON PROPRE COMPTE\r\nANNÉE DE LICENCE\r\n2023-2024 ( ESGIS BENIN)\r\nC E R T I F I C A T I O N S\r\nLES CERTIFICATIONS SUIVANTES SONT\r\nOBTENUS SUR OPENCLASSROOM\r\nPPH\r\nC, C++\r\nLinux\r\nHTML/CSS\r\nEXCEL\r\nJavaScript\r\nJava\r\nSQL\r\nVisual Basi', 'Complet'),
(6, '32d23109', 2, '', 'Application mobile de reconnaissance de texte dans les\r\nimages avec Flutter\r\nPlateforme de simulation de la DGPD(Direction général des\r\npolitiques de développement)\r\nApplication mobile de gestionnaire de contact\r\nMise en place d’un contrôleur de domaine sur Linux (UBUNTU', 'MesComperences'),
(7, '32d23109', 2, 'Servlet	\r\n• programme	Java	\r\n• s\'exécutant	côté	serveur	Web	\r\n• que	l\'on	peut	invoquer	à	l\'aide	d\'une	URL	\r\n• générant	du	code	HTML	\r\n• bien	adapté	à	l\'écriture	de	traitement	complexes	\r\n• contenant	majoritairement	du	code	Java	\r\n• et	quelques	parOes	de	c', '', ''),
(8, '32d23109', 3, '', 'jfjfjf ffjjfjfj ? rrfjfjf fjfjffj fjff', 'cedodoc');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `mdp` varchar(255) NOT NULL,
  `statut` varchar(255) NOT NULL,
  `visibilite` varchar(10) NOT NULL,
  `code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id_user`, `nom`, `adresse`, `mdp`, `statut`, `visibilite`, `code`) VALUES
(1, 'Cedric Leger Junior HOUNMADJAI', 'juniorhounmadjai@gmail.com', '1234', 'Admin', 'OUI', '32d23109'),
(2, 'SETO Marc', 'service.recrutemploi@gmail.com', 'aaaa', 'Membre', 'OUI', '32d23109'),
(3, 'ZINSOU Marc', 'marc@gmail.com', 'bbbb', 'Membre', 'OUI', '32d23109'),
(4, 'KINSIKLOUNON Josias', 'josias@gmail.com', 'cccc', 'Membre', 'OUI', '32d23109'),
(5, 'ODJO Benhila', 'odjo@gmail.com', 'dddd', 'Membre', 'OUI', '32d23109'),
(6, 'KAMI Kamilath', 'kami@gmail.com', 'eeee', 'Membre', 'OUI', '32d23109'),
(7, 'HESSOU Fiacre', 'fiacre@gmail.com', 'ffff', 'Membre', 'OUI', '32d23109'),
(8, 'DOSSA Ro', 'ro@gmail.com', 'gggg', 'Membre', 'OUI', '32d23109');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `archives`
--
ALTER TABLE `archives`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `commentaires`
--
ALTER TABLE `commentaires`
  ADD PRIMARY KEY (`id_comment`);

--
-- Index pour la table `espace`
--
ALTER TABLE `espace`
  ADD PRIMARY KEY (`id_espace`);

--
-- Index pour la table `publication`
--
ALTER TABLE `publication`
  ADD PRIMARY KEY (`id_pub`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `archives`
--
ALTER TABLE `archives`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `commentaires`
--
ALTER TABLE `commentaires`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `espace`
--
ALTER TABLE `espace`
  MODIFY `id_espace` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `publication`
--
ALTER TABLE `publication`
  MODIFY `id_pub` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
